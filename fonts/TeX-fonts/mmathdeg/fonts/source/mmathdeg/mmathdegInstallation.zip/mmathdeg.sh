#!/bin/bash

#(giovanni, 2022-05-24)

# This is a math-font installation using Typoma's MinionMath together with Teretisma-(Serif|Sans),
# as required by Teretisma Verlag.

# Required are adaptions of Typoma's MinionMath fonts installed for the TeX system with letters and
# figures taken from Teretisma-Serif and Teretisma-Sans. The reason is that letters and figures
# often occur with the same meaning in both, text and math mode . So, for example, a number written
# in text mode will be typeset in Teretisma-(Serif|Sans), a number written in math mode will be typeset in
# MinionMath. The objective is to avoid such font mixtures.

# - "Operator" fonts:
# Typoma uses either the OT1 or the T1 encoding. Both are completely installed for the
# Teretisma-(Serif|Sans). So nothing has to be done on the level of font installation. Later, in the
# style file, the respective math fonts just have to be redeclared.

# - "Letter" fonts: Typoma uses either the OML encoding or the newer "math core" MC encoding
# (cf. http://cahiers.gutenberg.eu.org/cg-bin/article/CG_1998___28-29_94_0.pdf or
# ftp://tug.ctan.org/tex-archive/fonts/utilities/fontinst/doc/talks/et99-font-tutorial.pdf). These
# two encodings include letters and figures, which are also provided by Teretisma-(Serif|Sans), as well as other
# symbols, which are not provided by Teretisma-(Serif|Sans). So, derivative virtual fonts have to be created from
# these MinionMath fonts where the letters and the figures are replaced by those from the Teretisma-(Serif|Sans)
# fonts.

# - Other fonts ("Symbols" etc.):
# The other MinionMath fonts have only very few characters which are also provided by the Teretisma-(Serif|Sans)
# fonts. It is not worth and even not recommended to replace single characters in these other math
# fonts. This also holds because those symbol characters normally do not occur in text mode, so that
# font mixtures are very unlikely. -- These other font encodings are: 
# OMS (symbols),
# OMS-rsfs (symbols),
# OMS-xits (symbols),
# MSP--base ("letters", but rather symbols),
# MSP ("letters", but rather symbols),
# MSP-rsfs ("letters", but rather symbols),
# MSP-xits ("letters", but rather symbols),
# MSA--base (symbolsb),
# MSA (symbolsb),
# MSB--base (symbolsc),
# MSB-eufr (symbolsc),
# MSB-xits (symbolsc),
# MSB (symbolsc),
# OMSA (AMSa),
# OMSB (AMSb),
# MXA--base%large symbols),
# MXA (large symbols),
# MXP--base (large symbols),
# MXP (large symbols),
# MSE--base (???).

# For Teretisma, only the medium and the bold font weights of MinionMath are taken into account. The
# medium font weight meets Teretisma-(Serif|Sans)'s regular weight.

# For the OML encoded fonts there are no property list. So we need to generate them:
vftovp -verbose MinionMath-MediumTiny-OML.vf MinionMath-MediumTiny-OML.tfm MinionMath-MediumTiny-OML.vpl
vftovp -verbose MinionMath-MediumCapt-OML.vf MinionMath-MediumCapt-OML.tfm MinionMath-MediumCapt-OML.vpl
vftovp -verbose MinionMath-Medium-OML.vf     MinionMath-Medium-OML.tfm     MinionMath-Medium-OML.vpl    
vftovp -verbose MinionMath-MediumSubh-OML.vf MinionMath-MediumSubh-OML.tfm MinionMath-MediumSubh-OML.vpl
vftovp -verbose MinionMath-MediumDisp-OML.vf MinionMath-MediumDisp-OML.tfm MinionMath-MediumDisp-OML.vpl
vftovp -verbose MinionMath-BoldTiny-OML.vf   MinionMath-BoldTiny-OML.tfm   MinionMath-BoldTiny-OML.vpl  
vftovp -verbose MinionMath-BoldCapt-OML.vf   MinionMath-BoldCapt-OML.tfm   MinionMath-BoldCapt-OML.vpl  
vftovp -verbose MinionMath-Bold-OML.vf	     MinionMath-Bold-OML.tfm	   MinionMath-Bold-OML.vpl	      
vftovp -verbose MinionMath-BoldSubh-OML.vf   MinionMath-BoldSubh-OML.tfm   MinionMath-BoldSubh-OML.vpl  
vftovp -verbose MinionMath-BoldDisp-OML.vf   MinionMath-BoldDisp-OML.tfm   MinionMath-BoldDisp-OML.vpl  
# The MinionMath property lists for the MC encoded fonts (from http://typoma.com/data/MinionMath-TeXLocal-current.zip):
# MinionMath-BoldTiny-MC--base.pl
# MinionMath-BoldCapt-MC--base.pl
# MinionMath-Bold-MC--base.pl
# MinionMath-BoldSubh-MC--base.pl
# MinionMath-BoldDisp-MC--base.pl
# MinionMath-MediumTiny-MC--base.pl
# MinionMath-MediumCapt-MC--base.pl
# MinionMath-Medium-MC--base.pl
# MinionMath-MediumSubh-MC--base.pl
# MinionMath-MediumDisp-MC--base.pl
# Otherwise try:
# vftovp -verbose MinionMath-BoldTiny-MC.vf MinionMath-BoldTiny-MC.tfm MinionMath-BoldTiny-MC.vpl
# vftovp -verbose MinionMath-BoldCapt-MC.vf MinionMath-BoldCapt-MC.tfm MinionMath-BoldCapt-MC.vpl
# vftovp -verbose MinionMath-Bold-MC.vf MinionMath-Bold-MC.tfm MinionMath-Bold-MC.vpl
# vftovp -verbose MinionMath-BoldSubh-MC.vf MinionMath-BoldSubh-MC.tfm MinionMath-BoldSubh-MC.vpl
# vftovp -verbose MinionMath-BoldDisp-MC.vf MinionMath-BoldDisp-MC.tfm MinionMath-BoldDisp-MC.vpl
# vftovp -verbose MinionMath-MediumTiny-MC.vf MinionMath-MediumTiny-MC.tfm MinionMath-MediumTiny-MC.vpl
# vftovp -verbose MinionMath-MediumCapt-MC.vf MinionMath-MediumCapt-MC.tfm MinionMath-MediumCapt-MC.vpl
# vftovp -verbose MinionMath-Medium-MC.vf MinionMath-Medium-MC.tfm MinionMath-Medium-MC.vpl
# vftovp -verbose MinionMath-MediumSubh-MC.vf MinionMath-MediumSubh-MC.tfm MinionMath-MediumSubh-MC.vpl
# vftovp -verbose MinionMath-MediumDisp-MC.vf MinionMath-MediumDisp-MC.tfm MinionMath-MediumDisp-MC.vpl

# From the Teretisma-(Serif|Sans) fonts, the following is required:
# - figures and medieval figures
# - latin letters
# - dotless i, dotless j
# - .,:;!?% (but parentheses, bracktes or braces are not replaced)
# - greek letters (because of font size problems and because of sansserif contexts)

#Presumed that the following Teretisma-(Serif|Sans) fonts are already installed:
vftovp -verbose Teretisma-Serif-Regular-tosf-oml.vf Teretisma-Serif-Regular-tosf-oml.tfm Teretisma-Serif-Regular-tosf-oml.vpl          #for OML
vftovp -verbose Teretisma-Serif-Italic-tosf-oml.vf Teretisma-Serif-Italic-tosf-oml.tfm Teretisma-Serif-Italic-tosf-oml.vpl             #for OML
vftovp -verbose Teretisma-Serif-Bold-tosf-oml.vf Teretisma-Serif-Bold-tosf-oml.tfm Teretisma-Serif-Bold-tosf-oml.vpl                   #for OML
vftovp -verbose Teretisma-Serif-Bold-Italic-tosf-oml.vf Teretisma-Serif-Bold-Italic-tosf-oml.tfm Teretisma-Serif-Bold-Italic-tosf-oml.vpl #for OML
tftopl -verbose Teretisma-Serif-Regular-tlf-ot1.tfm Teretisma-Serif-Regular-tlf-ot1.pl                                                    #for MC
vftovp -verbose Teretisma-Serif-Regular-tlf-oml.vf Teretisma-Serif-Regular-tlf-oml.tfm Teretisma-Serif-Regular-tlf-oml.vpl             #for MC
vftovp -verbose Teretisma-Serif-Italic-tlf-oml.vf Teretisma-Serif-Italic-tlf-oml.tfm Teretisma-Serif-Italic-tlf-oml.vpl                #for MC
tftopl -verbose Teretisma-Serif-Bold-tlf-ot1.tfm Teretisma-Serif-Bold-tlf-ot1.pl                                                          #for MC
vftovp -verbose Teretisma-Serif-Bold-tlf-oml.vf Teretisma-Serif-Bold-tlf-oml.tfm Teretisma-Serif-Bold-tlf-oml.vpl                      #for MC
vftovp -verbose Teretisma-Serif-Bold-Italic-tlf-oml.vf Teretisma-Serif-Bold-Italic-tlf-oml.tfm Teretisma-Serif-Bold-Italic-tlf-oml.vpl    #for MC
for i in Teretisma-Serif*.vpl ; do
  sed -i -e 's/\(CODINGSCHEME \)AUTOENC[^)]\+/\1TEX MATH ITALIC/g' $i
done
vftovp -verbose Teretisma-Sans-Regular-tosf-oml.vf Teretisma-Sans-Regular-tosf-oml.tfm Teretisma-Sans-Regular-tosf-oml.vpl          #for OML
vftovp -verbose Teretisma-Sans-Italic-tosf-oml.vf Teretisma-Sans-Italic-tosf-oml.tfm Teretisma-Sans-Italic-tosf-oml.vpl             #for OML
vftovp -verbose Teretisma-Sans-Bold-tosf-oml.vf Teretisma-Sans-Bold-tosf-oml.tfm Teretisma-Sans-Bold-tosf-oml.vpl                   #for OML
vftovp -verbose Teretisma-Sans-Bold-Italic-tosf-oml.vf Teretisma-Sans-Bold-Italic-tosf-oml.tfm Teretisma-Sans-Bold-Italic-tosf-oml.vpl #for OML
tftopl -verbose Teretisma-Sans-Regular-tlf-ot1.tfm Teretisma-Sans-Regular-tlf-ot1.pl                                               #for MC
vftovp -verbose Teretisma-Sans-Regular-tlf-oml.vf Teretisma-Sans-Regular-tlf-oml.tfm Teretisma-Sans-Regular-tlf-oml.vpl             #for MC
vftovp -verbose Teretisma-Sans-Italic-tlf-oml.vf Teretisma-Sans-Italic-tlf-oml.tfm Teretisma-Sans-Italic-tlf-oml.vpl                #for MC
tftopl -verbose Teretisma-Sans-Bold-tlf-ot1.tfm Teretisma-Sans-Bold-tlf-ot1.pl                                                     #for MC
vftovp -verbose Teretisma-Sans-Bold-tlf-oml.vf Teretisma-Sans-Bold-tlf-oml.tfm Teretisma-Sans-Bold-tlf-oml.vpl                      #for MC
vftovp -verbose Teretisma-Sans-Bold-Italic-tlf-oml.vf Teretisma-Sans-Bold-Italic-tlf-oml.tfm Teretisma-Sans-Bold-Italic-tlf-oml.vpl    #for MC
for i in Teretisma-Sans*.vpl ; do
  sed -i -e 's/\(CODINGSCHEME \)AUTOENC[^)]\+/\1TEX MATH ITALIC/g' $i
done

#Now, fontinst itself:
tex mmathdeg-drv
rm mmathdeg-drv.dvi
rm mmathdeg-drv.log
rm MinionMath*.vpl ; rm Teretisma-*.pl ; rm Teretisma-*.vpl ; rm MinionMath*.mtx ; rm Teretisma-*.mtx
for i in mmathdeg*.vpl ; do vptovf $i ; done
rm mmathdeg*.vpl

#Preparing the input file for nfssfont.tex:
ls -1t mmathdeg*.tfm > mmathdeg.in ; sed -i -e 's/\.tfm/\n\\table\\newpage\\init/g' -e '$ s/newpage\\init/bye/' mmathdeg.in

#Testing, using nfssfont:
latex nfssfont < mmathdeg.in ; rm nfssfont.log ; xdvi -geometry 1024x1280 -mgs5 nfssfont &

#Undoing the installation:
#rm mmathdeg*.tfm ; rm mmathdeg*.vf ; rm *.fd
