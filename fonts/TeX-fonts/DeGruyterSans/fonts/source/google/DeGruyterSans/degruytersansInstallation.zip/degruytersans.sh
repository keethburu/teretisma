#!/bin/bash

#GLYPHS AND ENCODINGS:
#The De Gruyter Sans fonts have mor than 3600 glyphs per font.
#So, a lot of TeX fonts with appropriate encodings are necessary.
#The standard LaTeX encodings are presented in the fontenc package.
#The MinionPro package is taken as a reference to decide which encodings at least should be included.
#OT1 (TeX text; fontools_ot1.enc copied from TEXMFDIST/fonts/enc/dvips/fontools/ and slightly adapted) is complete
  #(only the stroke for \l and \L is missing; but U+141 (Lslash) and U+142 (lsalsh) are added in slots beyond 0x7F;
  # extra ligatures U+FB05 (/longs_t) and U+FB06 (/s_t) are added).
#T1 (Cork; fontools_t1.enc copied from TEXMFDIST/fonts/enc/dvips/fontools/ and slightly adapted) is complete,
  #except /perthousandzero.
#TS1 (Cork companion; fontools_ts1.enc copied from TEXMFDIST/fonts/enc/dvips/fontools/ and adapted) works.
  #But the following characters are not found in the OTF:
     # /capitalcompwordmark   (???)
     # /tieaccentlowercase    (???)
     # /tieaccentcapital      (???)
     # /newtieaccentlowercase (???)
     # /newtieaccentcapital   (???) 
     # /hyphendblchar         (not a unicode)
     # /Omegainv              (U+2127)
     # /bigcircle             (U+25EF)
     # /born                  (not a unicode)
     # /divorced              (U+26AE)
     # /died                  (not a unicode)
     # /leaf                  (not a unicode)
     # /married               (U+26AD)
     # /musicalnote           (U+266A)
     # /hyphendblchar         (not a unicode)
     # /dollaroldstyle        (not a unicode)
     # /centoldstyle          (not a unicode)
     # /colonmonetary         (U+20A1)
     # /baht                  (U+0E3F)
     # /copyleft              (not a unicode)
  #And some (font specific) symbols are added (see fonttools_ts1.enc)
#LY1 (Y&Y; fontools_ly1.enc copied from TEXMFDIST/fonts/enc/dvips/fontools/ and slightly adapted) is complete.
#QX (polish; qx.enc copied from TEXMFDIST/fonts/enc/dvips/base/ and adapted)  works.
  #But the following characters are not found in the OTF:
     # /anglearc              (U+2222 SPHERICAL ANGLE)
     # /diameter              (U+2300 DIAMETER SIGN)
#L7x (lithuanian; copied from TEXMFDIST/fonts/enc/dvips/base/q-l7x-uni.enc l7x.enc and adapted) works.
  #But the following characters are not found in the OTF:
     # /uniEB4D
     # /uniF6BE
     # /uniEB2F
#OT2 (UW cyrillic; ot2.enc copied from MinionPor-package-sources:mn-ot2.enc and adapted) works.
  #But the following characters are not found in the OTF:
     # /cyrbreve              (U+F6D4)
#T2A (cyrillic; t2a.enc copied from TEXMFDIST/fonts/enc/t2/ (T2 package installed) and adapted) works.
  #But the following characters are not found in the OTF:
     # /cyrflex               (U+F6D5)
     # /dblgrave              (U+F6D6)
     # /cyrbreve              (U+F6D4)
#T2B (cyrillic; t2b.enc copied from TEXMFDIST/fonts/enc/t2/ (T2 package installed) and adapted) works.
  #But the following characters are not found in the OTF:
     # /cyrflex               (U+F6D5)
     # /dblgrave              (U+F6D6)
     # /cyrbreve              (U+F6D4)
     # 86                     (CYRILLIC CAPITAL LETTER DELTA)
     # 91                     (CYRILLIC CAPITAL LETTER ES WITH STROKE)
     # 9B                     (CYRILLIC CAPITAL LETTER EPSILON)
     # A6                     (CYRILLIC SMALL LETTER DELTA)
     # B1                     (CYRILLIC SMALL LETTER ES WITH STROKE)
     # BB                     (CYRILLIC SMALL LETTER EPSILON)
#T2C (cyrillic; t2c.enc copied from TEXMFDIST/fonts/enc/t2/ (T2 package installed) and adapted) works.
  #But the following characters are not found in the OTF:
     # /cyrflex               (U+F6D5)
     # /dblgrave              (U+F6D6)
     # /cyrbreve              (U+F6D4)
     # 85                     (CYRILLIC CAPITAL LETTER ER WITH DESCENDER)
     # 99                     (CYRILLIC CAPITAL LETTER EN WITH LEFT HOOK)
     # 9B                     (CYRILLIC CAPITAL LETTER ER WITH HOOK)
     # A5                     (CYRILLIC SMALL LETTER ER WITH DESCENDER)
     # B9                     (CYRILLIC SMALL LETTER EN WITH LEFT HOOK)
     # BB                     (CYRILLIC SMALL LETTER ER WITH HOOK)
#X2 (cyrillic; x2.enc copied from TEXMFDIST/fonts/enc/t2/ (T2 package installed) and adapted) works.
  #But the following characters are not found in the OTF:
     # /cyrflex               (U+F6D5)
     # /cyrbreve              (U+F6D4)
     # 18                     (PERTHOUSAND ZERO)
     # 1C                     (CYRILLIC CAPITAL LETTER DELTA)
     # 1D                     (CYRILLIC SMALL LETTER DELTA)
     # 1E                     (CYRILLIC CAPITAL LETTER EN WITH LEFT HOOK)
     # 1F                     (CYRILLIC SMALL LETTER EN WITH LEFT HOOK)
     # 4C                     (CYRILLIC CAPITAL LETTER EM WITH DESCENDER)
     # 50                     (CYRILLIC CAPITAL LETTER ER WITH DESCENDER)
     # 6C                     (CYRILLIC SMALL LETTER EM WITH DESCENDER)
     # 70                     (CYRILLIC SMALL LETTER ER WITH DESCENDER)
     # 9B                     (CYRILLIC CAPITAL LETTER EPSILON)
     # BB                     (CYRILLIC SMALL LETTER EPSILON)
#T3 (IPA; t3.enc copied from TEXMFDIST//fonts/enc/dvips/fontools/fontools-t3.enc and adapted) works.
  #But the following characters are not found in the OTF:
     # /subgrave              (???)
     # /subacute              (???)
     # /advancing             (???)
     # /celpal                (???)
     # /hooktop               (???)
     # /longleveltone %	128 uni02cd ? (???)
     # /longfallingtone1 %	129 (???)
     # /longfallingtone2 %	130 (???)
     # /longfallingtone3 %	131 (???)
     # /longfallingtone4 %	132 (???)
     # /longrisingtone1 %	133 (???)
     # /longrisingtone2 %	134 (???)
     # /longrisingtone3 %	135 (???)
     # /longrisingtone4 %	136 (???)
     # /shortleveltone %	137 (???)
     # /shortfallingtone1 %	138 (???)
     # /shortfallingtone2 %	139 (???)
     # /shortfallingtone3 %	140 (???)
     # /shortfallingtone4 %	141 (???)
     # /shortrisingtone1 %	142 (???)
     # /shortrisingtone2 %	143 (???)
     # /shortrisingtone3 %	144 (???)
     # /shortrisingtone4 %	145 (???)
     # /uni2502 %146 Vertical line (minor group) (U+2502)
     # /uni2551 %147 Double vertical line (Major group) (U+2551)
     # /uniA71C %downstep %148 Down arrow (Downstep) %MODIFIER LETTER RAISED DOWN ARROW? (U+A71C)
     # /uniA71B %upstep %149 Up arrow (Upstep) %MODIFIER LETTER RAISED UP ARROW? (U+A71B)
     # /gravedot %	142   (???)
     # /dotacute %	143   (???)
     # /longilefthook %166    (???)
     # /lyogh.old %	173   (???)
     # /turnce %	175   (???)
     # /omega.sc.ipa %	177   (???)
     # /pipe.var %	191   (???)
     # /babygamma.old %	200 variant of uni0264 (???)
     # /bardotlessjold%205    (???)
#TS3 (ipa symbol; with TEXMFDIST//fonts/enc/dvips/fontools/fontools-ts3.enc) works.
  #But cf. also TEXMFDIST/fonts/enc/dvips/cm-unicode/cmu-tipx.enc) 
  #But the following characters are not found in the OTF:
     #  /revpolhook (???)
     #  /rhooklong (???)
     #  /palhooklong (???)
     #  /palhookvar (???)
     #  /rectanglesuperscript (???)
     #  /leftarrowsuperscript (???)
     #  /scriptainverted (???)
     #  /uniA735 % ao
     #  /uniA72D %uni2C70 % fourlhook %  LATIN LETTER CUATRILLO
     #  /stretchcvarcurl (???)
     #  /dfronthook (???)
     #  /gammafronttail (???)
     #  /gammabacktail (???)
     #  /hhookrtail (???)
     #  /uniA727
     #  /hm (???)
     #  /nfrontbar (???)
     #  /female (U+2640)
     #  /uni26B2 % since unicode 5.0, femaleuncrossed
     #  /omegainverted (???)
     #  /plhook (???)
     #  /tfronthook (???)
     #  /invertedtcurl (???)
     #  /twoturned (???)
     #  /threeturned (???)
     #  /invertedglotstopcurl (???)
     #  /glotstopturned (???)
     #  /pipe.var (???)
     #  /lr (???)
     #  /ascinverted (???)
     #  /ao.sc (???)
     #  /uniA730 % f.sc.ipa
     #  /kscturned (???)
     #  /lscreversed (???)
     #  /uscturned (???)
#T4 (african latin; t4.enc generated using fc.rme (from the fc fonts package)) works.
  #But the following characters are not found in the OTF:
     # \~{\m E}   (not a unicode)
     # ~{\m O}    (not a unicode)
     # \b E       (not a unicode)
     # \b O       (not a unicode)
     # \~{\m e}   (not a unicode)
     # \~{\m o}   (not a unicode)
     # \b e       (not a unicode)
     # \b o       (not a unicode)
#T5 (vietnamese; t5.enc copied from TEXMFDIST/fonts/enc/dvips/vntex/ (vntex package installed) and adapted) is complete. 
#OT6, T6 (armenian; U+0530--U+058F; is not part of the OTF) -- not taken into account
#T7 (greek; encoding not defined so far, see the LGR encoding as the facto standard) not taken into account.
#LGR (greek 256, non-ASCII; fontools_lgr.enc copied from TEXMFDIST/fonts/enc/dvips/cm-unicode/cmu-g.enc and adapted) works.
  #But the following characters are not found in the OTF:
     # /u10144 % pentedeka 
     # /u10145 % pentehekaton 
     # /u10146 % penteqilioi 
     # /u10147 % pentemuria 
     # /varstigma (???)
     # /Alpharightphantomdiaeresis  (???)
     # /Upsilondiaeresisshifted  (???)
     # /alpharightphantomdiaeresis  (???)
     # /upsilondiaeresisshifted (???)
     # /widebreve (???)
  #But cf. also the original TEXMFDIST/fonts/enc/dvips/fontools/fontools_lgr.enc that is quite different.
#U (an extra encoding from the MinionPro package; u.enc copied from MinionPor-package-sources:mn-extra-u.enc and adapted) works.
  #This is added to provide (rarely needed) superior and inferior figures, numerators, and denominators
  #even without installing extra superior/inferior/numerator/denominator fonts with autoinst's options --inferiors, --superiors, and --fractions.
#2BS (an extra encoding to capture the characters from the blocks U+200--U+2FF and some not-unicoded symbols) works.
#PUA (an extra encoding to capture some characters from the private use area) works.
#OML (TeX math italic; oml.enc copied from TEXMFDIST/fonts/enc/dvips/base/texmital.enc) works.
  #But the following characters are not found in the OTF:
     # /arrowlefttophalf   (U+21BC)
     # /arrowleftbothalf   (U+21BD)
     # /arrowrighttophalf  (U+21C0)
     # /arrowrightbothalf  (U+21C1)
     # /arrowhookleft      (not a unicode)
     # /arrowhookright     (not a unicode)
     # /triangleright      (U+25B9)
     # /triangleleft       (U+25C3)
     # /star               (U+22C6)
     # /flat               (U+266D)
     # /natural            (U+266E)
     # /sharp              (U+266F)
     # /slurbelow          (U+2323)
     # /slurabove          (U+2322)
     # /lscript            (U+2113)
     # /vector             (U+20D7)
  #But cf. also TEXMFDIST/fonts/enc/dvips/fontools/fontools_oml.enc (for autoinst's math option).
#OMS (TeX math symbol; oms.enc copied from TEXMFDIST/fonts/enc/dvips/base/texmsym.enc) works.
  #But the following characters are not found in the OTF:
     # /diamondmath        (U+22C4)
     # /minusplus          (U+2213)
     # /circleplus         (U+2295)
     # /circleminus        (U+2296)
     # /circlemultiply     (U+2297)
     # /circledivide       (U+2298)
     # /circledot          (U+2299)
     # /openbullet         (U+25E6)
     # /equivasymptotic    (U+224D)
     # /equivalence        (U+2261)
     # /reflexsubset       (U+2286)
     # /reflexsuperset     (U+2287)
     # /precedesequal      (U+227C)
     # /followsequal       (U+227D)
     # /similar            (U+223C)
     # /propersubset       (U+2282)
     # /propersuperset     (U+2283)
     # /lessmuch           (U+226A)
     # /greatermuch        (U+226B)
     # /precedes           (U+227A)
     # /follows            (U+227B)
     # /similarequal       (U+2243)
     # /arrowdblleft       (U+21D0)
     # /arrowdblright      (U+21D2)
     # /arrowdblup         (U+21D1)
     # /arrowdbldown       (U+21D3)
     # /arrowdblboth       (U+21D4)
     # /proportional       (U+221D) 
     # /element            (U+2208)
     # /owner              (U+220B)
     # /triangle           (U+25B3)
     # /triangleinv        (U+25BD)
     # /mapsto             (???)
     # /universal          (U+2200)
     # /existential        (U+2203)
     # /emptyset           (U+2205)
     # /latticetop         (U+22A4)
     # /perpendicular      (U+22A5)
     # /aleph              (U+2135)
     # calligraphic A--Z   (approx. with ASCII letters)
     # /union              (U+222A)
     # /intersection       (U+2229)
     # /unionmulti         (U+228E)
     # /logicaland         (U+2227)
     # /logicalor          (U+2228)
     # /turnstileleft      (U+22A2)
     # /turnstileright     (U+22A3)
     # /floorleft          (U+230A)
     # /floorright         (U+230B)
     # /ceilingleft        (U+2308)
     # /ceilingright       (U+2309)
     # /arrowdblbothv      (U+21D5)
     # /wreathproduct      (U+2240)
     # /coproduct          (U+2210)
     # /nabla              (U+2207)
     # /unionsq            (U+2294)
     # /intersectionsq     (U+2293)
     # /subsetsqequal      (U+2291)
     # /supersetsqequal    (U+2292)
     # /club               (U+2663)
     # /diamond            (U+2662; approx. with U+25CA)
     # /heart              (U+2661)
     # /spade              (U+2660)
#OMX (TeX math extension; cf. TEXMFDIST/fonts/enc/dvips/base/texmext.enc; has no match in the OTF) not taken into account.
#The following encodings are not taken into account: LV1 (MicroPress) and CB (greek; cb.enc from the cbfonts package).
#Note that e.g. --extra="-s greek" does not work. It creates .fd files but no .tfm files.

#OPENTYPE TYPOGRAPHIC FEATURES:
#The following features known by autoinst are not supported by De Gruyter Sans:
#-swsh (Swash)
#-titl (Titling Alternates)
#But De Gruyter Sans has salt (Stylistic Alternates), i.e. ss01, ss02, ss03, and ss04 (see otfinfo -g *.otf | grep ss0x).
 #These are already captured in the 2BS encoding (see above).

./autoinst -encoding=OT1,T1,TS1,LY1,QX,L7x,OT2,T2A,T2B,T2C,X2,T3,TS3,T4,T5,LGR,U,2BS,PUA,OML,OMS \
 -noswash -notitling -smallcaps -noinferiors -nosuperiors -nofractions -noornaments -t1suffix -verbose -target=. \
 De-Gruyter-Sans-Regular.otf De-Gruyter-Sans-Italic.otf De-Gruyter-Sans-Bold.otf De-Gruyter-Sans-Bold-Italic.otf

#./autoinst -encoding=T1,TS1 \
# -nooldstyle -notabular -noswash -notitling -nosmallcaps -noinferiors -nosuperiors -nofractions -noornaments -t1suffix -verbose -target=. \
# De-Gruyter-Sans-Regular.otf


#only for testing: 
# -extra='--kpathsea-debug=-1' \
# -extra='--unicoding "ff =: ff f_f ; uniFB00 =: uniFB00 ff f_f ; ffi =: ffi f_f_i ; uniFB03 =: uniFB03 ffi f_f_i ; ffl =: ffl f_f_l ; uniFB04 =: uniFB04 ffl f_f_l"' \

#Some adaptions ara made to autoinst (avoiding local sub-dirs, OML encoding, U encoding, resulting .sty file, ...; cf. "giovanni").

#T updmap -user --enable Map=DeGruyterSans.map

#Adjusting file names for L7x encodings:
mmv "L7X*.fd" 'L7x#1.fd'

#Adding a patch for the L7x encoding to DeGruyterSans.sty:
sed -i -e 's/\\endinput/%patch for loading L7x encoding (because of filename parsing problems with lowercase x -- problem with the lithuanian package)\n\\expandafter\\ifx\\csname T@L7x\\endcsname\\relax\\else\\input{L7xDeGruyterSans-TLF.fd}\\fi\n\n\\endinput/g' DeGruyterSans.sty
#... and to *.fd:
sed -i -e 's/L7X/L7x/g' *.fd

#Adding declarations for encodings 2BS and PUA:
sed -i -e 's/\\endinput/%declaring fontspecific encodings:\n\\DeclareFontEncoding{2BS}{}{}\n\\DeclareFontSubstitution{\\LastDeclaredEncoding}{DeGruyterSans-TLF}{m}{n}\n\\DeclareFontEncoding{PUA}{}{}\n\\DeclareFontSubstitution{\\LastDeclaredEncoding}{DeGruyterSans-TLF}{m}{n}\n\\DeclareEncodingSubset{TS1}{DeGruyterSans-*}{2}\n\n\\endinput/g' DeGruyterSans.sty

#Adding figure variant declarations to DeGruyterSans.sty:
sed -i -e '/\\endinput/d' DeGruyterSans.sty
for i in DeGruyterSans.sty ; do cat figuvars.tex >> $i ; done

#Preparing the input file for nfssfont.tex:
ls -1rt *.tfm | grep -v base > degruytersans.in ; sed -i -e 's/\.tfm/\n\\table\\newpage\\init/g' -e '$ s/newpage\\init/bye/' degruytersans.in

#Undoing the installation:
# rm -r ~/.texlive2021/
# rm *.fd ; rm a_*.enc ; rm *.tfm ; rm *.vf ; rm *.map ; rm *.sty ; rm *.pfb ; rm degruyter*.log
